//const char* ssid = "Honeypot3";
//const char* ssid = "N_Samsung_hotspot"; 
//const char* password = "Newton00!";
//const char* ssid = "TinCanGuest";
//const char* password = "tincan01";
const char* ssid = "DDCIOT";
const char* password = "ddcIOT2020";
