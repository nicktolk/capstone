jpeglib for Marmalade
=====================

This module can be used to build the standard jpeglib library into airplay
applications.

The source is downloaded and compiled unmodified from:

    http://www.ijg.org/files/jpegsrc.v6b.tar.gz

The included example will render a jpeg to the screen using the s3eSurface API.
